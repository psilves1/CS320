#include <string>
#include <cmath>
#include <iostream> 

int setAssociative(unsigned long long** cache, int cacheSize, unsigned long long addr, int associativity);
void shuffle(unsigned long long* arr, int sizeOfArr);
void shuffle2(unsigned long long* arr, int sizeOfArr, int avoidThisIndex);