#include <string>
#include <cmath>
#include <iostream>

int prefetchMiss(unsigned long long** cache, int cacheSize, unsigned long long addr, int associativity);

