#include <string>
#include <cmath>
#include <iostream>

int prefetch(unsigned long long** cache, int cacheSize, unsigned long long addr, int associativity);

