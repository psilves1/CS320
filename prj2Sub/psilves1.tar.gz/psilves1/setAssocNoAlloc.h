#include <string>
#include <cmath>
#include <iostream>

int setAssocNoAlloc(std::string instructionType, unsigned long long **cache, int cacheSize, unsigned long long addr, int associativity);