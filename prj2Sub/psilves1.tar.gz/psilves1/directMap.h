#include <string>
#include <cmath>

int directMap(std::string instructionType, unsigned long long*cache, int cacheSize, unsigned long long addr);